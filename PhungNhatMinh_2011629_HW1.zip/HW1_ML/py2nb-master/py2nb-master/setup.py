from distutils.core import setup

setup(
    name="py2nb",
    description="Convert python script into jupyter notebook",
    packages=["py2nb"],
    author="Continuum Analytics, Inc.",
    license='BSD',
)
